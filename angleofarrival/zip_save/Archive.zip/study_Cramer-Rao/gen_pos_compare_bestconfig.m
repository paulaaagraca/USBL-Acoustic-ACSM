clear

%load best configurations from my script for positions in s
load('best_config_view_mine2.mat', 'ind_best_config');
load('estimated_s2.mat', 'estimate_s');

n_diff_elements = 0;


for i = 1:length(ind_best_config)
    [best_rad_view_ind(i),diff_radius_myvsfisher(i)] = config_gen_fisher( estimate_s(:,i), ind_best_config(i));
    
    if best_rad_view_ind(i) ~= ind_best_config(i)
        n_diff_elements = n_diff_elements+1;
    end
end

save('../study_Cramer-Rao/best_config_view_fisher.mat', 'best_rad_view_ind', '-mat')

max_diff = max(diff_radius_myvsfisher);

plot (diff_radius_myvsfisher)
