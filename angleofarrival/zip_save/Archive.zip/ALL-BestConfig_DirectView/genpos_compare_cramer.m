
clear

x = -1000:500:1000;
y = -1000:500:1000;
z = -1000:500:1000;

cnt_s = 1;
for xi = 1:length(x)
    for yi = 1:length(y)
        for zi = 1:length(z)
            s(:,cnt_s) = [x(xi);y(yi);z(zi)];
            cnt_s = cnt_s + 1;
        end
    end
end

for i = 1:cnt_s-1
    [ind_best_config(i), estimate_s(:,i)] = test_config4position_timediff( s(:,i) );
end


save('../study_Cramer-Rao/best_config_view_mine3.mat', 'ind_best_config', '-mat')
save('../study_Cramer-Rao/estimated_s3.mat', 'estimate_s', '-mat')